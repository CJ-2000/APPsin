/* Capa Services:*/
// Devuelve el resultado de la capa de persistencia o DAO
// Deben estar todos los métodos de la capa DAO

// Si afecta el contenido de la BD, pensar en incluir el concepto de TRANSACCIONES
// También se ve lógica como validaciones
package com.udep.sin2021.appsin.services;

import com.udep.sin2021.appsin.dao.DocumentoDao;
import java.sql.SQLException;

public class DocumentoServices {

    private DocumentoDao documentoDao = new DocumentoDao();

    public int RegistraDocumento(String codigo, int idEstado, String version, int dni, String fecha, String idCarpetaRaiz, String idArea, String idUnidad, String idTipo, String idformato) throws SQLException, ClassNotFoundException {
        return documentoDao.RegistraDocumento(codigo, idEstado, version, dni, fecha, idCarpetaRaiz, idArea, idUnidad, idTipo, idformato);
    }

    public String NombreCarpeta_String(String nombreColumna, String nombreTabla, String columna_condicion, String dato_condicion) throws SQLException, ClassNotFoundException {
        return documentoDao.NombreCarpeta_String(nombreColumna, nombreTabla, columna_condicion, dato_condicion);
    }

    public String NombreCarpeta_Integer(String nombreColumna, String nombreTabla, String columna_condicion, int dato_condicion) throws SQLException, ClassNotFoundException {
        return documentoDao.NombreCarpeta_Integer(nombreColumna, nombreTabla, columna_condicion, dato_condicion);
    }

    public int EliminaDocumento(String idSeguimiento) throws SQLException, ClassNotFoundException {
        return documentoDao.EliminaDocumento(idSeguimiento);
    }
    
    public int Contar_registros(int modo, String tabla, String campo_condicion,int dato_condicion) throws SQLException, ClassNotFoundException {
        return documentoDao.Contar_registros(modo, tabla, campo_condicion, dato_condicion);
    }
    
    public String documento_reciente(String resultado) throws SQLException, ClassNotFoundException {
        return documentoDao.documento_reciente(resultado);
    }

}
