/* Capa Controllers:*/
// Este servlet es llamado para eliminar: archivo local y registro en la base de datos

package com.udep.sin2021.appsin.controllers;

import static com.udep.sin2021.appsin.beans.Global.carpeta_Principal;
import static com.udep.sin2021.appsin.beans.Global.ruta_documentos;
import com.udep.sin2021.appsin.services.DocumentoServices;
import com.udep.sin2021.appsin.services.UsuarioServices;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletEliminaFoto extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, ClassNotFoundException {
        
        // Extrae parámetro "nombre" del enlace predecesor
        //Ejemplo: "juanperez.png"
        String nombre = request.getParameter("ruta");
        
        //Nombre del usuario a eliminar
        String usuario = request.getParameter("usuario");
        
        //DNI de la persona a eliminar su registro
        String dni = request.getParameter("DNI"); 
        
        // Ruta de la carpeta destino donde se va a buscar el archivo
        String ruta =  carpeta_Principal + nombre; 
        
        // Se declara el archivo que se va a eliminar
        File file = new File(ruta);                
        response.setContentType("text/html;charset=GBK"); 
        
        try (PrintWriter out = response.getWriter()) {
                
            // Crea un nuevo UsuarioServices
            UsuarioServices us = new UsuarioServices();
            int rpta = us.EliminaFoto(dni);
            if (rpta == 0){
                file.delete(); //Elimina el archivo

                /*Lanza una alerta en javascript*/ 
                out.println("<script type=\"text/javascript\">");
                out.println("alert('Usuario " + usuario + " eliminado'); location='vistas/dashboard.jsp'; ");
                out.println("</script>");      
            } else {                   
                                /*Lanza una alerta en javascript*/ 
                out.println("<script type=\"text/javascript\">");
                out.println("alert('Hay un error con la base de datos. No se pudo eliminar');");
                out.println("location='vistas/table_users.jsp';");
                out.println("</script>"); 
                
            }

        } catch (Exception e) {
            System.out.println("Hay un problema " + e);
        }
        
        
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(ServletEliminaFoto.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(ServletEliminaFoto.class.getName()).log(Level.SEVERE, null, ex);
        }
    }


    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
