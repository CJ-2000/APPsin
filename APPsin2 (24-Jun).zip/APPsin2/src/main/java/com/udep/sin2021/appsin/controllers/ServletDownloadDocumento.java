/* Capa Controllers:*/
// Captura parámetros

package com.udep.sin2021.appsin.controllers;

import static com.udep.sin2021.appsin.beans.Global.ruta_documentos;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletDownloadDocumento extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
                
        // Extrae parámetro "nombre" del formulario predecesor
        //Ejemplo: "PC-08 Taller de Servicios-MS V.08.pdf"
        String nombre = request.getParameter("nombre");
        request.setCharacterEncoding("UTF-8");
        
        // Ruta de la carpeta destino donde se va a buscar el archivo
        String ruta =  ruta_documentos + request.getParameter("ruta"); 

        // El archivo puede ser de cualquier formato
        // O sea, se puede descargar tanto pdf, excel, word, etc
        response.setContentType("application/octet-stream");  
        
        // Solo guarda el archivo, no lo va a mostrar
        response.setHeader("Content-Disposition","attachment; filename=\"" + nombre + "\"");   
        
        // Se declara el archivo que se va a descargar
        File f = new File(ruta + nombre);        
         OutputStream out = response.getOutputStream();
         FileInputStream in = new FileInputStream(f);
         byte[] buffer = new byte[4096];
         int length;
         // Se lee el archivo que se va a descargar 
         while ((length = in.read(buffer)) > 0){
            out.write(buffer, 0, length);
         }
         //Envia el archivo al navegador
         in.close();
         out.flush();        

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
