/* Servlet enlaza con archivos existentes para mostrar en documentos HTML o JSP*/
// No es de elaboración propia (Modificado de https://balusc.omnifaces.org/2007/07/fileservlet.html)
package com.udep.sin2021.appsin.controllers;

import static com.udep.sin2021.appsin.beans.Global.carpeta_Principal;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLDecoder;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class fileServlet extends HttpServlet {

    // Constante 
    private static final int DEFAULT_BUFFER_SIZE = 10240; // 10KB.

    // Propiedad
    private String filePath;

    // Acciones
    @Override
    public void init() throws ServletException {

        // Define la ruta base
        this.filePath = carpeta_Principal;

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Obtener el archivo solicitado por información de ruta de acceso.
        String requestedFile = request.getPathInfo();

        // Compruebe si el archivo se proporciona realmente al URI de la solicitud.
        if (requestedFile == null) {
            // Haga lo suyo si el archivo no se proporciona al URI de solicitud.
            // Inicie una excepción, envíe 404, o muestre la página predeterminada/de advertencia, o simplemente ignórela.
            response.sendError(HttpServletResponse.SC_NOT_FOUND); // 404.
            return;
        }

        // Descodifique el nombre de archivo (puede contener espacios y encendido) y prepare el objeto de archivo.
        File file = new File(filePath, URLDecoder.decode(requestedFile, "UTF-8"));

        // Compruebe si el archivo realmente existe en el sistema de archivos.
        if (!file.exists()) {
            // Haga lo suyo si el archivo parece no existir.
            // Inicie una excepción, envíe 404, o muestre la página predeterminada/de advertencia, o simplemente ignórela.
            response.sendError(HttpServletResponse.SC_NOT_FOUND); // 404.
            return;
        }

        // Obtener el tipo de contenido por nombre de archivo.
        String contentType = getServletContext().getMimeType(file.getName());

        // Si el tipo de contenido es desconocido, establezca el valor predeterminado.
        // Para agregar nuevos tipos de contenido, agregue una nueva entrada mime-mapping en web.xml.
        if (contentType == null) {
            contentType = "application/octet-stream";
        }

        // Respuesta del servlet de init.
        response.reset();
        response.setBufferSize(DEFAULT_BUFFER_SIZE);
        response.setContentType(contentType);
        response.setHeader("Content-Length", String.valueOf(file.length()));
        response.setHeader("Content-Disposition", "attachment; filename=\"" + file.getName() + "\"");

        // Preparar secuencias.
        BufferedInputStream input = null;
        BufferedOutputStream output = null;

        try {
            // Abre streams.
            input = new BufferedInputStream(new FileInputStream(file), DEFAULT_BUFFER_SIZE);
            output = new BufferedOutputStream(response.getOutputStream(), DEFAULT_BUFFER_SIZE);

            // Escriba el contenido del archivo en la respuesta.
            byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
            int length;
            while ((length = input.read(buffer)) > 0) {
                output.write(buffer, 0, length);
            }
        } finally {
            // Gently close streams.
            close(output);
            close(input);
        }
    }

    // Ayudantes (se pueden refactorizar a la clase de utilidad pública) ----------------------------------------
    private static void close(Closeable resource) {
        if (resource != null) {
            try {
                resource.close();
            } catch (IOException e) {
                // Haz lo tuyo con la excepción. Imprímalo, logíralo o envíelo por correo.
                e.printStackTrace();
            }
        }
    }
}
