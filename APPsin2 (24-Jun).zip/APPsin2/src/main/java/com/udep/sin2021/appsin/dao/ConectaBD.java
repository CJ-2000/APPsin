/* Capa Persistencia o DAO:*/
// Toma la BD y crea un objeto

package com.udep.sin2021.appsin.dao;

import static com.udep.sin2021.appsin.beans.Global.url;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConectaBD {
    public static Connection initializeDatabase()
        throws SQLException,ClassNotFoundException {     
        
        Connection con = DriverManager.getConnection(url);
        
        return con;
    }
}
