/* Capa Controllers:*/
// Captura parámetros
package com.udep.sin2021.appsin.controllers;

import static com.udep.sin2021.appsin.beans.Global.url;
import com.udep.sin2021.appsin.beans.Usuario;
import com.udep.sin2021.appsin.services.DocumentoServices;
import com.udep.sin2021.appsin.services.UsuarioServices;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ServletValidaUsuario extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {

        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");

        try (PrintWriter out = response.getWriter()) {
            //Recojo los parámetros enviados por el form de la página precedente
            String user = request.getParameter("usuario");
            String clave = request.getParameter("clave");

            //Creo un nuevo Usuario
            Usuario usuario = new Usuario();
            usuario.setUsuario(user);
            usuario.setClave(clave);

            //Creo un nuevo UsuarioServices
            UsuarioServices us = new UsuarioServices();
            int rpta = us.buscarUsuario(user, clave, usuario);
            //System.out.println(rpta);
            switch (rpta) {
                case 404:
                    /*Si no hay resultados, lanza una alerta y se dirige al mismo login*/
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('No hay conexión con la base de datos MySQL');");
                    out.println("location='index.jsp';");
                    out.println("</script>");
                    break;
                case 0:
                    /*Si no hay resultados, lanza una alerta y se dirige al mismo login*/
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('Usuario o contraseña no existe');");
                    out.println("location='index.jsp';");
                    out.println("</script>");
                    break;
                default:
                    //Si hay resultados:

                    //Guarda los atributos del mismo usuario, para luego invocarlo
                    String nombres = usuario.getNombres();
                    String apellidos = usuario.getApellidos();
                    String rutaFoto = usuario.getRutaFoto();
                    String Idrol  = usuario.getIdrol();
                    int dni = usuario.getDni();

                    //Guarda nombre y apellidos en toda la sesión
                    HttpSession session = request.getSession();
                    session.setAttribute("nombres", nombres);
                    session.setAttribute("apellidos", apellidos);
                    session.setAttribute("rutaFoto", rutaFoto);
                    session.setAttribute("Idrol", Idrol);
                    
                    //Guarda parámetros de la base de datos para usar en JSP
                    session.setAttribute("url", url);
                    
                    //Creo un nuevo DocumentoServices
                    DocumentoServices ds = new DocumentoServices();
                    int dashboard_1 = ds.Contar_registros(0, "seguimiento", null,0); //número total de documentos
                    int dashboard_2 = ds.Contar_registros(1, "seguimiento", "DNI",dni); //número total de documentos, por dni
                    String dashboard_3 =  ds.documento_reciente("D"); //nombre del último documento
                    String dashboard_4 =  ds.documento_reciente("F"); //fecha del último documento
                    session.setAttribute("dashboard_1", dashboard_1);
                    session.setAttribute("dashboard_2", dashboard_2);
                    session.setAttribute("dashboard_3", dashboard_3);
                    session.setAttribute("dashboard_4", dashboard_4);

                    //Por medio de la consola avisa que hubo un nuevo acceso
                    SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM-dd 'a las' HH:mm:ss");
                    Date date = new Date(System.currentTimeMillis());
                    System.out.println(" AVISO: "+nombres + " " + apellidos + " ha iniciado sesion " + "(" + formatter.format(date)+ ")" );
                    
                    //Se dirige a la página principal
                    response.sendRedirect(request.getContextPath() + "/vistas/dashboard.jsp");
                                        
                    break;
            }
        }

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ServletValidaUsuario.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ServletValidaUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ServletValidaUsuario.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ServletValidaUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
