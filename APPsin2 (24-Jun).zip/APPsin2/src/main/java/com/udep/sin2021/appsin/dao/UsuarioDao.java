/* Capa Persistencia o DAO:*/
// Toma la BD y crea un objeto

package com.udep.sin2021.appsin.dao;

import com.udep.sin2021.appsin.beans.Usuario;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class UsuarioDao {
    //Esta clase contiene métodos que devuelven entero, lista o algún otro tipo de dato
    
    public int buscarUsuario(String usuario, String clave, Usuario u1) throws ClassNotFoundException, SQLException{    
        //Este método se usa para validar al usuario. Es necesario contar con los parámetros asignados
        //Retorna valor int: 0 o 1
        try (Connection con = ConectaBD.initializeDatabase()) {
            Statement stmt =con.createStatement();
            String consulta = "SELECT * FROM usuario WHERE usuario = '" + usuario + "' AND clave = '" + clave + "'";
            ResultSet rs= stmt.executeQuery(consulta);

            if (!rs.next()) {
                //No existe coincidencia
                return 0;
            } else{
                //Guarda los datos de la consulta dentro de los atributos de Usuario
                u1.setDni(rs.getInt("dni"));
                u1.setNombres(rs.getString("nombres"));
                u1.setApellidos(rs.getString("apellidos"));
                u1.setUsuario(rs.getString("usuario"));
                u1.setClave(rs.getString("clave"));
                u1.setEmail(rs.getString("email"));
                u1.setTelefono(rs.getInt("telefono"));
                u1.setEmergencia(rs.getInt("emergencia"));
                u1.setIdrol(rs.getString("idrol"));
                u1.setRutaFoto(rs.getString("rutaFoto"));
                // Cierra la conexión de la BD
                con.close();                
                return 1;
            }    
            
        } catch(SQLException error) {
           return 404;     
        }
    }
    
    public int EliminaFoto(String dni) throws ClassNotFoundException, SQLException{    
        //Este método se usa para validar al usuario. Es necesario contar con los parámetros asignados
        //Retorna valor int: 0 o 1
        try (Connection con = ConectaBD.initializeDatabase()) { //Conecta con la base de datos
            Statement stmt =con.createStatement(); //Crea el espacio para almacenar resultados de la consulta u operacion
            String consulta = "DELETE FROM usuario WHERE DNI = '" + dni+ "'";
            ResultSet rs= stmt.executeQuery(consulta);

            if (!rs.next()) { 
                //No hubo respuesta
                return 0;
            } else{ 
                //Se logró eliminar
                // Cierra la conexión de la BD
                con.close();                
                return 1;
            }    
        } catch(SQLException error) { //Si no conecta la base de datos
           return 404;     
        }
    }

    public int ActualizarUsuario(int modo, String dni, String nombres, String apellidos, String usuario, String clave, String email, String telefono, String emergencia, String idrol, String rutaFoto) throws SQLException, ClassNotFoundException {
        //Este método se usa para actualizar datos en la BD, de un usuario
        //Retorna valor int: 0 o 1
        Connection con = ConectaBD.initializeDatabase(); //Conecta con la base de datos
        Statement stmt = con.createStatement(); //Crea el espacio para almacenar resultados de la consulta u operacion
        String consulta; //modo 0 no modifica la ruta de foto, modo 1 sí modifica la ruta de foto
        
        if (modo == 0) {
            consulta = "UPDATE usuario SET "
                    + "nombres = '" + nombres + "', "
                    + "apellidos = '" + apellidos + "', "
                    + "usuario = '" + usuario + "', "
                    + "clave = '" + clave + "', "
                    + "email = '" + email + "', "
                    + "telefono = '" + telefono + "', "
                    + "emergencia = '" + emergencia + "', "
                    + "idrol = '" + idrol + "'"
                    + "WHERE dni = '" + dni + "'";
        } else {
            consulta = "UPDATE usuario SET "
                    + "nombres = '" + nombres + "', "
                    + "apellidos = '" + apellidos + "', "
                    + "usuario = '" + usuario + "', "
                    + "clave = '" + clave + "', "
                    + "email = '" + email + "', "
                    + "telefono = '" + telefono + "', "
                    + "emergencia = '" + emergencia + "', "
                    + "idrol = '" + idrol + "', "
                    + "rutaFoto = '" + rutaFoto + "'"
                    + "WHERE dni = '" + dni + "'";
        }


        int filas = stmt.executeUpdate(consulta);
        if (filas > 0) { //Se logró eliminar
            // Cierra la conexión de la BD
            con.close();
            return 1;
        } else { //No hubo respuesta
            // Cierra la conexión de la BD
            con.close();
            return 0;
        }
    }      
    
    public int RegistraUsuario(String dni, String nombres, String apellidos, String usuario, String clave, String email, String telefono, String emergencia, String idrol, String rutaFoto) throws ClassNotFoundException, SQLException{    
        //Este método se usa para registrar un usuario. Es necesario contar con los parámetros asignados
        //Retorna valor int: 0 o 1
        Connection con = ConectaBD.initializeDatabase(); //Conecta con la base de datos
        Statement stmt =con.createStatement(); //Crea el espacio para almacenar resultados de la consulta u operacion
        String consulta = "INSERT INTO usuario "
                + "(DNI,nombres,apellidos,usuario,clave,email,telefono,emergencia,idrol,rutaFoto) VALUES "
                + "('" + dni + "'"
                + ",'" + nombres + "'" 
                + ",'" + apellidos + "'" 
                + ",'" + usuario + "'" 
                + ",'" + clave + "'" 
                + ",'" + email + "'" 
                + ",'" + telefono + "'"
                + ",'" + emergencia + "'"
                + ",'" + idrol + "'" 
                + ",'" + rutaFoto + "'" 
                + ")";
        
        int filas = stmt.executeUpdate(consulta);
        if (filas > 0) { //Se logró insertar
            // Cierra la conexión de la BD
            con.close();
            return 1;
        } else { //No hubo respuesta
            // Cierra la conexión de la BD
            con.close();
            return 0;
        }
    }
    
    
}
