/* Capa Controllers:*/
// Este servlet es llamado para cerrar la sesión 

package com.udep.sin2021.appsin.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ServletCerrarSesion extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        try (PrintWriter out = response.getWriter()) {

        // Remueve el atributo "nombre"
        HttpSession session = request.getSession();
        String nombres = (String) session.getAttribute("nombres");
        String apellidos= (String) session.getAttribute("apellidos");
        session.removeAttribute("nombres"); // Elimina el atributo asignado al elemento Usuario y no permitir interactuar con la aplicación
        session.invalidate(); // Caduca toda la sesión
        
        //Por medio de la consola avisa que hubo un nuevo acceso
        SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM-dd 'a las' HH:mm:ss");
        Date date = new Date(System.currentTimeMillis());
        System.out.println(" AVISO: "+nombres + " " + apellidos + " ha finalizado sesion " + "(" + formatter.format(date)+ ")" );
        
        //Muestra alerta de sesión cerrada
        out.println("<script type=\"text/javascript\">");
        out.println("alert('Cierre de sesión correcto');");
        out.println("location='index.jsp';");
        out.println("</script>");    
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
