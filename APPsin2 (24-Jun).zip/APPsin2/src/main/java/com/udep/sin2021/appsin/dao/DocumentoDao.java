/* Capa Persistencia o DAO:*/
// Toma la BD y crea un objeto

package com.udep.sin2021.appsin.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DocumentoDao {
    //Esta clase contiene métodos que devuelven entero, lista o algún otro tipo de dato

    public int RegistraDocumento(String codigo, int idEstado, String version, int dni, String fecha, String idCarpetaRaiz, String idArea, String idUnidad, String idTipo, String idformato) throws SQLException, ClassNotFoundException {
        //Este método se usa para registrar en la BD, los datos de un documento nuevo
        //Retorna valor int: 0 o 1
        Connection con = ConectaBD.initializeDatabase(); //Conecta con la base de datos
        Statement stmt = con.createStatement(); //Crea el espacio para almacenar resultados de la consulta u operacion

        String consulta = "INSERT INTO seguimiento "
                + "(codigo,idEstado,version,dni,fecha,idCarpetaRaiz,idArea,idUnidad,idTipo,idformato) "
                + "VALUES ( '" + codigo + "'," + idEstado + ",'" + version + "',"
                + dni + ",'" + fecha + "','" + idCarpetaRaiz + "','"
                + idArea + "','" + idUnidad + "','" + idTipo + "','"
                + idformato + "'   )";

        int filas = stmt.executeUpdate(consulta);
        if (filas > 0) { //Se logró insertar
            // Cierra la conexión de la BD
            con.close();
            return 1;
        } else { //No hubo respuesta
            // Cierra la conexión de la BD
            con.close();
            return 0;
        }
    }

    public int EliminaDocumento(String idSeguimiento) throws SQLException, ClassNotFoundException {
        //Este método se usa para eliminar en la BD, los datos de un documento nuevo
        //Retorna valor int: 0 o 1
        Connection con = ConectaBD.initializeDatabase(); //Conecta con la base de datos
        Statement stmt = con.createStatement(); //Crea el espacio para almacenar resultados de la consulta u operacion

        String consulta = "DELETE FROM seguimiento WHERE idSeguimiento = '" + idSeguimiento + "'";

        int filas = stmt.executeUpdate(consulta);
        if (filas > 0) { //Se logró eliminar
            // Cierra la conexión de la BD
            con.close();
            return 1;
        } else { //No hubo respuesta
            // Cierra la conexión de la BD
            con.close();
            return 0;
        }
    }
    
    public String NombreCarpeta_String(String nombreColumna, String nombreTabla, String columna_condicion, String dato_condicion) throws SQLException, ClassNotFoundException {
        //Este método se usa para consultar en la BD, los datos de un documento
        //Retorna texto
        Connection con = ConectaBD.initializeDatabase(); //Conecta con la base de datos
        Statement stmt = con.createStatement(); //Crea el espacio para almacenar resultados de la consulta u operacion

        String consulta
                = "SELECT " + nombreColumna
                + " FROM " + nombreTabla
                + " WHERE " + columna_condicion + " = '" + dato_condicion + "' ";

        ResultSet rs = stmt.executeQuery(consulta);

        if (!rs.next()) {
            //Sí existe coincidencia
            return null;
        } else {
            con.close();
            String resultado = rs.getString(nombreColumna);
            return resultado;
        }

    }

    public String NombreCarpeta_Integer(String nombreColumna, String nombreTabla, String columna_condicion, int dato_condicion) throws SQLException, ClassNotFoundException {
        //Este método se usa para consultar en la BD, los datos de un documento
        //Retorna texto
        Connection con = ConectaBD.initializeDatabase(); //Conecta con la base de datos
        Statement stmt = con.createStatement(); //Crea el espacio para almacenar resultados de la consulta u operacion

        String consulta
                = "SELECT " + nombreColumna
                + " FROM " + nombreTabla
                + " WHERE " + columna_condicion + " = " + dato_condicion + " ";
        ResultSet rs = stmt.executeQuery(consulta);

        if (!rs.next()) {
            //No existe coincidencia
            return null;
        } else {
            //Sí existe coincidencia
            con.close();
            String resultado = rs.getString(nombreColumna);
            return resultado;
        }
    }
    
    
    public int Contar_registros(int modo, String tabla, String campo_condicion,int dato_condicion) throws SQLException, ClassNotFoundException {
        //Este método se usa para consultar en la BD, los datos de un documento
        //Retorna cantidad de registros
        Connection con = ConectaBD.initializeDatabase(); //Conecta con la base de datos
        Statement stmt = con.createStatement(); //Crea el espacio para almacenar resultados de la consulta u operacion
        
        String consulta;      
        if (modo == 0){
            consulta = "SELECT COUNT(*) AS Total FROM " + tabla;
            ResultSet rs = stmt.executeQuery(consulta);
            
            if (!rs.next()) {
                //No existe coincidencia
                return 0;
            } else {
                //Sí existe coincidencia
                con.close();
                int resultado = rs.getInt("Total");
                return resultado;
            }        
            
        }else{
            consulta = "SELECT COUNT(*) AS Total FROM " + tabla + " WHERE "+ campo_condicion + " = "+ dato_condicion;
            ResultSet rs = stmt.executeQuery(consulta);
            
            if (!rs.next()) {
                //No existe coincidencia
                return 0;
            } else {
                //Sí existe coincidencia
                con.close();
                int resultado = rs.getInt("Total");
                return resultado;
            } 
            
        }
    }
    
    public String documento_reciente(String resultado) throws SQLException, ClassNotFoundException {
        //Este método se usa para consultar en la BD, los datos del documento más reciente
        //Retorna texto
        Connection con = ConectaBD.initializeDatabase(); //Conecta con la base de datos
        Statement stmt = con.createStatement(); //Crea el espacio para almacenar resultados de la consulta u operacion

        String consulta = "SELECT CONCAT(codigo,' V.',version,'.',idformato) as Documento , Fecha FROM seguimiento ORDER BY idSeguimiento DESC LIMIT 1";
        ResultSet rs = stmt.executeQuery(consulta);

        if (!rs.next()) {
            //No existe coincidencia
            return null;
        } else {
            //Sí existe coincidencia
            con.close();
            if ("D".equals(resultado)){ //D de documento
                resultado = rs.getString("Documento");
            } else { // Fecha
                resultado = rs.getString("Fecha");
            }
            return resultado;
        }        
    }
    
    
}
