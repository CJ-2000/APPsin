/* Capa bean:*/
// Lleva y trae información, sin otra lógica*/

//Atributos privados no pueden modificarse directamente, se debe usar métodos accesores como Refactor - Encapsulate Fields

package com.udep.sin2021.appsin.beans;

public class Documento {

    private int idSeguimiento;
    private String codigo;
    private int idEstado;
    private String version;
    private int dni;
    private String fecha;
    private String idCarpetaRaiz;
    private String idArea;
    private String idUnidad;
    private String idTipo;
    private String idformato;
    
    /**
     * @return the idSeguimiento
     */
    public int getIdSeguimiento() {
        return idSeguimiento;
    }

    /**
     * @param idSeguimiento the idSeguimiento to set
     */
    public void setIdSeguimiento(int idSeguimiento) {
        this.idSeguimiento = idSeguimiento;
    }

    /**
     * @return the codigo
     */
    public String getCodigo() {
        return codigo;
    }

    /**
     * @param codigo the codigo to set
     */
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    /**
     * @return the idEstado
     */
    public int getIdEstado() {
        return idEstado;
    }

    /**
     * @param idEstado the idEstado to set
     */
    public void setIdEstado(int idEstado) {
        this.idEstado = idEstado;
    }

    /**
     * @return the version
     */
    public String getVersion() {
        return version;
    }

    /**
     * @param version the version to set
     */
    public void setVersion(String version) {
        this.version = version;
    }

    /**
     * @return the dni
     */
    public int getDni() {
        return dni;
    }

    /**
     * @param dni the dni to set
     */
    public void setDni(int dni) {
        this.dni = dni;
    }

    /**
     * @return the fecha
     */
    public String getFecha() {
        return fecha;
    }

    /**
     * @param fecha the fecha to set
     */
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    /**
     * @return the idCarpetaRaiz
     */
    public String getIdCarpetaRaiz() {
        return idCarpetaRaiz;
    }

    /**
     * @param idCarpetaRaiz the idCarpetaRaiz to set
     */
    public void setIdCarpetaRaiz(String idCarpetaRaiz) {
        this.idCarpetaRaiz = idCarpetaRaiz;
    }

    /**
     * @return the idArea
     */
    public String getIdArea() {
        return idArea;
    }

    /**
     * @param idArea the idArea to set
     */
    public void setIdArea(String idArea) {
        this.idArea = idArea;
    }

    /**
     * @return the idUnidad
     */
    public String getIdUnidad() {
        return idUnidad;
    }

    /**
     * @param idUnidad the idUnidad to set
     */
    public void setIdUnidad(String idUnidad) {
        this.idUnidad = idUnidad;
    }

    /**
     * @return the idTipo
     */
    public String getIdTipo() {
        return idTipo;
    }

    /**
     * @param idTipo the idTipo to set
     */
    public void setIdTipo(String idTipo) {
        this.idTipo = idTipo;
    }

    /**
     * @return the idformato
     */
    public String getIdformato() {
        return idformato;
    }

    /**
     * @param idformato the idformato to set
     */
    public void setIdformato(String idformato) {
        this.idformato = idformato;
    }
    

    

}
