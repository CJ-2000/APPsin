/* Capa Services:*/
// Devuelve el resultado de la capa de persistencia o DAO
// Deben estar todos los métodos de la capa DAO

// Si afecta el contenido de la BD, pensar en incluir el concepto de TRANSACCIONES
// También se ve lógica como validaciones

package com.udep.sin2021.appsin.services;

import com.udep.sin2021.appsin.beans.Usuario;
import com.udep.sin2021.appsin.dao.UsuarioDao;
import java.sql.SQLException;

public class UsuarioServices {
    private UsuarioDao usuarioDao = new UsuarioDao();
    
    public int buscarUsuario(String usuario, String clave, Usuario u1) throws ClassNotFoundException, SQLException{    
        return usuarioDao.buscarUsuario(usuario, clave, u1);
    }
    
    public int EliminaFoto(String dni) throws ClassNotFoundException, SQLException{
        return usuarioDao.EliminaFoto(dni);
    }
    
    public int RegistraUsuario(String dni, String nombres, String apellidos, String usuario, String clave, String email, String telefono, String emergencia, String idrol, String rutaFoto) throws ClassNotFoundException, SQLException{    
        return usuarioDao.RegistraUsuario(dni, nombres, apellidos, usuario, clave, email, telefono, emergencia, idrol, rutaFoto);
    }
    
    public int ActualizarUsuario(int modo, String dni, String nombres, String apellidos, String usuario, String clave, String email, String telefono, String emergencia, String idrol, String rutaFoto) throws SQLException, ClassNotFoundException {
        return usuarioDao.ActualizarUsuario(modo, dni, nombres, apellidos, usuario, clave, email, telefono, emergencia, idrol, rutaFoto);
    }    
    
}
